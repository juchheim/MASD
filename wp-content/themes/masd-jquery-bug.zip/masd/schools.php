<?php

$args = array(
    'count' => true
);
$number_of_sites = get_sites( $args );

$i = 0;

while ( $i <= $number_of_sites ) {
    $i++;
    $url = get_home_url( $i );
    $current_blog_details = get_blog_details( array( 'blog_id' => $i ) );

    if ($current_blog_details->blogname != "MASD") {
        echo "<a href='" .$url. "'>".$current_blog_details->blogname."</a>";
        echo "<br>";
    }
    
}

?>