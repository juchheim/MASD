<?php if(is_page('teachers')){ ?>

<div class="threeColumn">

<?php

    /* if the current site is MASD */
    if ( absint( get_current_blog_id() ) == 1 ) {

        $pod = pods( 'teacher' );
        $params = array(
            'limit' => -1, 
            'orderby' => 'last_name ASC'
        );
        
        $pod->find( $params );
                
        if ($pod->total() > 0) {
            while ($pod->fetch()) {
                $first_name = $pod->display('first_name');
                $last_name = $pod->display('last_name');
                $school = $pod->display('school');
                $image = $pod->display('image');
                $email = $pod->display('email');
                $grade = $pod->display('grade');
                $subject = $pod->display('subject');
                $image = $pod->display( 'image');
                ?>
                <div class="threeColumnSingle <?php if($column_count_total == $pod->total()) { echo "threeColumnSingleLast"; } ?>"><?php
                
                if($image != "") {
                    echo "<img src='";
                    echo $image;
                    echo "' class='teacherPhoto' loading='lazy' >";
                    echo "<br>";
                    } else {
                        echo "<img class='teacherPhoto' src='/wp-content/uploads/2024/04/no_image_available-1.jpeg' loading='lazy' /><br>";
                    }
                    echo $first_name." ". $last_name. "<br>";
                    echo $school;
                    echo "<br>";
                    if( $email != "" ){
                        echo "<a href='mailto:". $email ."'>". $email ."</a>";
                        echo "<br>";
                    }
                    if( $grade != "" ){ echo $grade. " "; }
                    if( $subject != "" ){ echo $subject; }
                    
                    echo "</div>";

                    // Free memory by unsetting variables
                    unset($first_name, $last_name, $school, $image, $email, $grade, $subject);
                }
            }
            echo "</div>";
        }	
        restore_current_blog();	 
    }


    global $blog_id;
    global $site_name;
    $current_blog_details = get_blog_details( array( 'blog_id' => $blog_id ) );
    /* echo $current_blog_details->blogname; */

    /* if the current site isn't MASD  */
    if ( $current_blog_details->blogname  != 'MASD' ) {
        
        switch_to_blog( 1 );

        $pod = pods( 'teacher' );
        $params = array(
            'where' => "school.meta_value = '" . $current_blog_details->blogname . "' ",
            'limit' => -1, 
            'orderby' => 'last_name ASC'
        );
        
        $pod->find( $params );
                
        if ($pod->total() > 0) {
            while ($pod->fetch()) { 

                $first_name = $pod->display('first_name');
                $last_name = $pod->display('last_name');
                $image = $pod->display('image');
                $email = $pod->display('email');
                $grade = $pod->display('grade');
                $subject = $pod->display('subject');

                ?>
                <div class="threeColumnSingle <?php if($column_count_total == $pod->total()) { echo "threeColumnSingleLast"; } ?>"><?php
                
                    if($image != "") {
                        echo "<img src='";
                        echo $image;
                        echo "' class='teacherPhoto'>";
                        echo "<br>";
                    } else {
                        echo "<img class='teacherPhoto' src='/wp-content/uploads/2024/04/no_image_available-1.jpeg' /><br>";
                    }
                    echo $first_name." ". $last_name. "<br>";
                    if( $email != "" ){
                        echo "<a href='mailto:". $email ."'>". $email ."</a>";
                        echo "<br>";
                    }
                    if( $grade != "" ){ echo $grade. " "; }
                    if( $subject != "" ){ echo $subject; }

                    echo "</div>";

                    // Free memory by unsetting variables
                    unset($first_name, $last_name, $image, $email, $grade, $subject);
                }
                
            }
            echo "</div>";
        }	
        restore_current_blog();	 
    
?>