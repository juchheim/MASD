<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package MASD
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<?php wp_head(); ?>

</head>

<body <?php body_class(); ?>>


<div class="google_translate_element_wrapper"><div id="google_translate_element"></div></div>
 
    <script type="text/javascript">
        function googleTranslateElementInit() {
            new google.translate.TranslateElement(
            {
                pageLanguage: 'en',
                includedLanguages: 'en,es,ar',
                layout: google.translate.TranslateElement.InlineLayout.simple
            },
            'google_translate_element'
        );
        }
		
    </script>
 
    <script type="text/javascript"
            src=
			"https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit">
    </script>


<?php wp_body_open(); ?>
<div id="page" class="site">
	<header id="masthead" class="site-header">
		<div class="header-inner">
			<div class="logo">
				<!-- Add your logo here -->
				<?php "<span style=padding: left 30px;".the_custom_logo()."</span>" ; ?>
			</div>
			<nav>
			<button class="menu-toggle" aria-controls="primary-menu" aria-expanded="false"><?php esc_html_e( 'Primary Menu', 'masd' ); ?></button>
			<?php
				wp_nav_menu(
					array(
						'theme_location' => 'menu-1',
						'menu_id'        => 'primary-menu',
					)
				);
			?>
			</nav>
		</div>
	</header><!-- #masthead -->
</div>

	